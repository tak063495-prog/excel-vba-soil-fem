param($d)
. "$d\common.ps1"
$src="$env:USERPROFILE\manual_rewrite_20261021\workbook\ui_20261020\2DSoilFEM_ui_20261021.xlsm"
$r4="$env:USERPROFILE\manual_shots_20261021\run4"
function L($m){ "$(Get-Date -f HH:mm:ss) $m"|Out-File -Append "$d\main.log" -Encoding utf8 }
if(Get-Process EXCEL -EA 0){ L "EXCEL already running, abort"; "x"|Out-File "$d\stop"; exit }
$x=New-Object -ComObject Excel.Application
$me=(Get-Process EXCEL|Sort StartTime|Select -Last 1).Id; "$me"|Out-File "$d\mypid.txt"; L "PID $me"
$x.Visible=$true; $x.WindowState=-4137; $x.DisplayAlerts=$false
$script:b=$null
function Snap($name,$addrs){ Start-Sleep -Milliseconds 1500; $h=[IntPtr]$x.Hwnd; (New-Object -ComObject WScript.Shell).AppActivate([int]$me)|Out-Null; [U]::SetForegroundWindow($h)|Out-Null; Start-Sleep -Milliseconds 2000; $r=New-Object U+R; [U]::GetWindowRect($h,[ref]$r)|Out-Null; $w=$r.Rt-$r.L;$ht=$r.B-$r.T; $bm=New-Object Drawing.Bitmap $w,$ht; $g=[Drawing.Graphics]::FromImage($bm); $g.CopyFromScreen($r.L,$r.T,0,0,$bm.Size); $bm.Save("$d\img\$name.png"); $g.Dispose();$bm.Dispose()
  $rs=@(); $pn=$x.ActiveWindow.ActivePane; $ws=$x.ActiveSheet
  foreach($a in $addrs){ try{ $rg=$ws.Range($a); $rs+=@{a=$a;l=$pn.PointsToScreenPixelsX($rg.Left)-$r.L;t=$pn.PointsToScreenPixelsY($rg.Top)-$r.T;r=$pn.PointsToScreenPixelsX($rg.Left+$rg.Width)-$r.L;b=$pn.PointsToScreenPixelsY($rg.Top+$rg.Height)-$r.T} }catch{} }
  (@{name=$name;rects=$rs}|ConvertTo-Json -Compress -Depth 4)|Out-File -Append "$d\rects.jsonl" -Encoding utf8; L "snap $name" }
function Go($n){ [void]$script:b.Activate(); $ws=$script:b.Worksheets.Item($n); $ws.Visible=-1; [void]$ws.Activate(); $x.ActiveWindow.Zoom=100; $x.ActiveWindow.ScrollRow=1; $x.ActiveWindow.ScrollColumn=1; $ws.Range("A1").Select()|Out-Null; return $ws }
function M($m,$lab){ Start-Sleep 3; $lab|Out-File "$d\label.txt" -Encoding utf8; L "run $m"; $x.EnableEvents=$true; try{ $x.Run($m)|Out-Null; L "ret $m" }catch{ L "ERR $m $($_.Exception.Message)" }; $x.EnableEvents=$false; Start-Sleep 8 }
function MS($k,$v){ try{ if($v -is [string]){ $x.Run('FEMWriteTextSetting',$k,$v)|Out-Null } else { $x.Run('FEMWriteNumericSetting',$k,[double]$v)|Out-Null } }catch{ L "ERRSET $k $_" } }
function S($ws,$a,$v){ $rg=$ws.Range([string]$a); $u=$v; if($u -is [psobject]){$u=$u.psobject.BaseObject}; if($u -is [string]){ $rg.Value2=[string]$u } else { $rg.Value2=[double]$u } }
function OpenF($from,$tag){ if($script:b){ $script:b.Close($false); Start-Sleep 2 }; $f="$d\2DSoilFEM_$($tag)_20261021_$(Get-Date -f HHmm).xlsm"; Copy-Item $from $f; $script:b=$x.Workbooks.Open($f); $x.EnableEvents=$false; L "open $f from $from" }
function Mat($rows){ $ws=Go '�ޗ��f�[�^'; $ws.Range("A2:M20").ClearContents()|Out-Null; $r=2; foreach($q in $rows){ $c=0; foreach($v in $q){ $col=[char](65+$c); S $ws "$col$r" $v; $c++ }; $r++ }; return $ws }
function Shape($pts,$bnds){ $ws=Go '�`�����'; $ws.Range("B8:D60").ClearContents()|Out-Null; $ws.Range("G8:J30").ClearContents()|Out-Null; $r=8; foreach($q in $pts){ S $ws "B$r" $q[0]; S $ws "C$r" $q[1]; S $ws "D$r" $q[2]; $r++ }; $ws.Range("I8:I30").NumberFormat='@'; $r=8; foreach($q in $bnds){ S $ws "G$r" ($r-7); S $ws "H$r" $q[0]; S $ws "I$r" $q[1]; S $ws "J$r" $q[2]; $r++ }; return $ws }
function Stages($rows){ $ws=Go '�X�e�[�W'; $ws.Range("A2:F20").ClearContents()|Out-Null; $r=2; foreach($q in $rows){ S $ws "A$r" ($r-1); S $ws "B$r" $q[0]; if($q[1] -ne $null){S $ws "C$r" $q[1]}; if($q[2] -ne $null){S $ws "D$r" $q[2]}; S $ws "E$r" 1; if($q[3]){S $ws "F$r" $q[3]}; $r++ }; return $ws }
function Loads($rows){ $ws=Go '�ډ�'; $ws.Range("A2:J20").ClearContents()|Out-Null; $r=2; foreach($q in $rows){ $c=0; foreach($v in $q){ if($v -ne $null){ $col=[char](65+$c); S $ws "$col$r" $v }; $c++ }; $r++ }; return $ws }
function Dump($tag){ $o=@{tag=$tag}; $n=$script:b.Worksheets.Item('�ߓ_�f�[�^'); $o.nodes=$n.Cells($n.Rows.Count,1).End(-4162).Row-1; $e=$script:b.Worksheets.Item('�v�f�f�[�^'); $o.elems=$e.Cells($e.Rows.Count,1).End(-4162).Row-1; $s=$script:b.Worksheets.Item('�X�e�[�W����'); $t=@(); for($r=1;$r -le 13;$r++){ $row=@(); for($c=1;$c -le 10;$c++){ $row+=$s.Cells($r,$c).Text }; $t+=($row -join ' | ') }; $o.stage=$t; ($o|ConvertTo-Json -Compress)|Out-File -Append "$d\results.jsonl" -Encoding utf8; L "dump $tag" }
function RunAll($tag){ $ws=Go '����p�l��'; M 'FEMUiRun' "$tag-preview"; "1"|Out-File "$d\analyzing"; M 'FEMUiStartFromMesh' "$tag-run"; Remove-Item "$d\analyzing" -EA 0; Dump $tag; $ws=Go '�X�e�[�W����'; Snap "$($tag)_result_table" @('A1:J6') }
function View($tag,$sel,$scale,$name){ $ws=Go '�o�́E�\��'; MS 'VIEW_COLOR_RESULT' $sel; MS 'VIEW_DISP_SCALE' $scale; $ws=Go '�o�́E�\��'; Snap "$($tag)_out_$name" @('C17','C18'); M 'FEMViewResult' "$tag-view"; Snap "$($tag)_fig_$name" @() }
function Fig($tag){ try{ $ws=Go '�}'; Snap "$($tag)_figsheet" @() }catch{ L "no �} $tag" } }
$m1=@(1,20000,0.3,1,18,30,10,0,1,'ON','SOIL')
$rect=@(@(1,0,0),@(2,12,0),@(3,12,6),@(4,0,6)); $rb=@(,@('�O��','1,2,3,4',1))
$steps=[ordered]@{}
# 1) re-capture stage input for ex4/ex5 with unique names
$steps['ex4in']={ OpenF $src 'ex4_stagein'; $ws=Stages @(@('GRAVITY',$null,$null,'�����n�Ղ̎��d'),@('DEATH',2,$null,'�̈�2���@��'),@('BIRTH',3,$null,'�̈�3�𐷓y')); Snap 'ex4_stagein' @('A2:F4','B2:C4') }
$steps['ex5in']={ OpenF $src 'ex5_stagein'; $ws=Loads @(,@(1,'BOX','Y','FORCE',-10,4,6,8,6,'��ʒ����ɐߓ_��')); $ws=Stages @(@('GRAVITY',$null,$null,'�����n�Ղ̎��d'),@('LOAD',1,$null,'�ډ׃O���[�v1����p')); Snap 'ex5_stagein' @('A2:F3','B3:C3') }
# 2) existing large-run workbooks (copies of run4 outputs)
$steps['road']={ Copy-Item "$r4\road\soilfem_native_x64.dll" $d -Force; OpenF "$r4\road\A.xlsm" 'road_A'
  $ws=Go '�`�����'; Snap 'road_shape' @('B8:D25','G8:J15'); $ws=Go '�ޗ��f�[�^'; Snap 'road_mat' @('A2:K9','J2:J9'); $ws=Go '�X�e�[�W'; Snap 'road_stage' @('A2:F12','B2:D12'); $ws=Go '�X�e�[�W����'; Snap 'road_result_table' @('A1:J12','H2:H12'); Fig 'road_A'
  $ws=Go '�o�́E�\��'; Snap 'road_out_A' @('C27','J28:J29'); OpenF "$r4\road\B.xlsm" 'road_B'; Fig 'road_B'; $ws=Go '�o�́E�\��'; Snap 'road_out_B' @('C27','J28:J29') }
$steps['wall']={ OpenF "$r4\wall\A.xlsm" 'wall_A'; $ws=Go '�`�����'; Snap 'wall_shape' @('B8:D30','G8:J11'); $ws=Go '�ޗ��f�[�^'; Snap 'wall_mat' @('A2:K4','K2:K4'); $ws=Go '�X�e�[�W'; Snap 'wall_stage' @('A2:F5'); $ws=Go '�X�e�[�W����'; Snap 'wall_result_table' @('A1:J5','E5'); Fig 'wall_A' }
$steps['tunnel']={ OpenF "$r4\tunnel\A.xlsm" 'tunnel_A'; $ws=Go '�ޗ��f�[�^'; Snap 'tunnel_mat' @('A2:K7','K7'); $ws=Go '�X�e�[�W'; Snap 'tunnel_stage' @('A2:F11','B2:D11'); $ws=Go '�X�e�[�W����'; Snap 'tunnel_result_table' @('A1:J11','E11'); Fig 'tunnel_A'; $ws=Go '����p�l��'; M 'FEMUiShowNodes' 'tunnel-nodes'; Snap 'tunnel_nodes' @() }
# 3) JOINT example (new run)
$steps['joint']={ OpenF $src 'joint_strongblock75'; $ws=Mat @($m1,@(2,20000,0.3,1,20,30,1000,0,1,'ON','SOIL'),@(3,100000,0.3,1,0,20,5,0,0,'ON','JOINT',100000,1)); Snap 'joint_mat' @('A2:M4','K4:L4')
  $p=@(@(1,0,0),@(2,12,0),@(3,12,4),@(4,8,4),@(5,4,4),@(6,0,4),@(7,4,6),@(8,8,6)); $ws=Shape $p @(@('�O��','1,2,3,4,5,6',1),@('�O��','5,4,8,7',1)); Snap 'joint_shape' @('B8:D15','G8:J9')
  $ws=Go '�ڍ�'; $ws.Range("A2:E10").ClearContents()|Out-Null; S $ws 'A2' 1; S $ws 'B2' 2; S $ws 'C2' 3; S $ws 'D2' 1; S $ws 'E2' '�u���b�N���'; Snap 'joint_joint' @('A2:D2','C2')
  $ws=Go '���b�V���ݒ�'; M 'FEMUiGenerateShape' 'joint-mesh'; Snap 'joint_mesh' @()
  $ws=Loads @(,@(2,'BOX','X','FORCE',4.4,4,6,8,6,'�u���b�N��ʂɐ�����')); Snap 'joint_load' @('A2:E2','F2:I2')
  $ws=Stages @(@('GRAVITY',$null,$null,'���d'),@('LOAD',2,$null,'������')); Snap 'joint_stagein' @('A2:F3')
  RunAll 'joint'; View 'joint' 2 100 'sy'
  $ws=Go '����p�l��'; M 'FEMPracticalShowJointResults' 'joint-res'; Snap 'joint_results' @('A1:L12')
  try{ $j=$script:b.Worksheets.Item('�ڍ�����'); $t=@(); $lr=$j.Cells($j.Rows.Count,1).End(-4162).Row; for($r=1;$r -le [Math]::Min($lr,80);$r++){ $row=@(); for($c=1;$c -le 14;$c++){ $row+=$j.Cells($r,$c).Text }; $t+=($row -join ' | ') }; ($t -join "`n")|Out-File "$d\joint_results.txt" -Encoding utf8 }catch{ L "no �ڍ����� $_" } }
foreach($k in @("joint")){ try{ & $steps[$k] }catch{ L "EXERR $k $($_.Exception.Message) @ $($_.InvocationInfo.ScriptLineNumber)" } }
L "all done"
try{ $script:b.Save(); $script:b.Close($false) }catch{}; $x.Quit(); Start-Sleep 3; if(Get-Process -Id $me -EA 0){ Stop-Process -Id $me -Force; L "killed own $me" }
"x"|Out-File "$d\stop"
