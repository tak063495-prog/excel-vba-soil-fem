入力と実計算結果を保存した検証コピーです。元入力を変更する前に別名保存してください。開発者向けのWaterFixtureDriverを含みます。
cutoff: 定常浸透と遮水構造。box: 乾燥空洞。box_inside: 内水位1.5m。stages: 水位変更・掘削・再有効化。slope_low_srm: 水位1mの固定水圧SRM。
DLLは1個です。outの全ログ・チェックポイント・数値はdocs/groundwater-evidence/20261022/records.zipを参照。
