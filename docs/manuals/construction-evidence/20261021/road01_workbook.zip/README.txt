Dedicated calculated example copy.
Keep the XLSM and single DLL together.
Bearing examples impose gravity-referenced incremental settlement on a soil strip; not a rigid contact footing model.
See the manual and reproduction records for inputs and limitations.
