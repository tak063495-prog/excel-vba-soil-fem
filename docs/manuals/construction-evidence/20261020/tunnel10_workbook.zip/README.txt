Dedicated calculated example copy.
Keep XLSM and the single DLL in the same folder.
See docs/manuals/README.md for the model scope, flow rule, Fs interpretation and reproduction.
