﻿Attribute VB_Name = "ThisWorkbook"
Attribute VB_Base = "0{00020819-0000-0000-C000-000000000046}"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = True
Attribute VB_TemplateDerived = False
Attribute VB_Customizable = True

Private Sub Workbook_Open()
  Dim eventsSaved As Boolean
  eventsSaved = Application.EnableEvents
  On Error GoTo Failed
  ' Layout/registry writes are not user input edits. Keep the saved dirty marker.
  Application.EnableEvents = False
  FEMWriteBuildStamp False
  FEMWaterInstallUi
  FEM24Install
  FEM24Home
  GoTo Finish
Failed:
  FEM24Error = "画面の初期化に失敗しました。" & Err.description
  If Not SuppressUserMessages Then MsgBox FEM24Error, vbExclamation
Finish:
  Application.EnableEvents = eventsSaved
End Sub

Private Sub Workbook_SheetChange(ByVal sh As Object, ByVal target As range)
  Dim sheetName As String
  Dim cell As range
  Dim keyName As String
  Dim invalidateAnalysis As Boolean
  Dim invalidateSettings As Boolean
  Dim rngC As range
  Dim rngE As range
  If AnalysisRunning Then Exit Sub
  If FEM24IsPage(sh.name) Then
    FEM24Changed sh, target
    Exit Sub
  End If
  On Error Resume Next
  sheetName = sh.name
  If FEMUiIsSettingsSheet(sheetName) Then
    FEMUiSettingsChanged sh, target
    Exit Sub
  End If
  If sheetName = "節点データ" Or sheetName = "材料データ" Or sheetName = "要素データ" _
     Or sheetName = "水条件" Or sheetName = "形状入力" Or sheetName = "ステージ" Or sheetName = "載荷" Or sheetName = "図形定義" Or sheetName = "接合" Then
    FEM24ClearPlot
    FEMViewerMarkDirty
    FEMUiInvalidateMeshPreview
    AnalysisOK = False
    ResultRevision = 0
    P1ResultReady = False
    Exit Sub
  End If
  If sheetName <> "設定" Then Exit Sub
  Set rngC = Application.Intersect(target, sh.columns(3))
  Set rngE = Application.Intersect(target, sh.columns(5))
  If rngC Is Nothing And rngE Is Nothing Then Exit Sub
  invalidateAnalysis = False
  invalidateSettings = False
  If Not rngE Is Nothing Then
    For Each cell In rngE.cells
      If cell.row >= 4 Then
        invalidateSettings = True
        invalidateAnalysis = True
        Exit For
      End If
    Next cell
  End If
  If Not rngC Is Nothing Then
    For Each cell In rngC.cells
      keyName = UCase$(Trim$(CStr(sh.cells(cell.row, 5).value2)))
      If Len(keyName) > 0 And keyName <> "設定キー" Then
        invalidateSettings = True
        If left$(keyName, 6) <> "ADAPT_" And left$(keyName, 4) <> "RCM_" And left$(keyName, 12) <> "MESH_REPAIR_" _
           And left$(keyName, 5) <> "VIEW_" And left$(keyName, 6) <> "DEBUG_" And left$(keyName, 7) <> "EXPORT_" _
           And left$(keyName, 18) <> "MESH_QUALITY_LAST_" _
           And left$(keyName, 20) <> "MESH_QUALITY_REPAIR_" Then
          invalidateAnalysis = True
        End If
      End If
    Next cell
  End If
  If invalidateSettings Then FEMInvalidateSettingCache
  If invalidateAnalysis Then
    FEM24ClearPlot
    FEMViewerMarkDirty
    FEMUiInvalidateMeshPreview
    AnalysisOK = False
    ResultRevision = 0
    P1ResultReady = False
  End If
End Sub

Private Sub Workbook_SheetActivate(ByVal sh As Object)
  If FEM24Installed() Then FEM24Refresh sh
End Sub


